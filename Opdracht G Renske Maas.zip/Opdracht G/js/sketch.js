function setup() {
    createCanvas(800, 800);
}

function draw() {
    background(155, 174, 204);

    var ellipseWidth = 200;
    var ellipseHeight = 185;
    
    //grass house 1
    fill(73, 107, 81)
    strokeWeight(0);
    ellipse(75, 165, ellipseWidth, ellipseHeight);
    ellipse(100, 155, ellipseWidth, ellipseHeight);
    ellipse(125, 150, ellipseWidth, ellipseHeight);
    ellipse(150, 145, ellipseWidth, ellipseHeight);
    ellipse(175, 150, ellipseWidth, ellipseHeight);
    ellipse(200, 155, ellipseWidth, ellipseHeight);
    ellipse(225, 165, ellipseWidth, ellipseHeight);
    ellipse(250, 180, ellipseWidth, ellipseHeight);
    ellipse(270, 200, ellipseWidth, ellipseHeight);

    //shadow door 1
    fill(64, 89, 62);
    ellipse(150, 145, 160, 150);

    //door 1
    fill(62, 112, 138);
    stroke(69, 77, 94);
    strokeWeight(1);
    ellipse(150, 145, 120, 120);

    //doorknob 1
    fill(115, 104, 100);
    strokeWeight(1);
    ellipse(150, 140, 20, 20);
    
    //grass
    fill (76, 133, 91);
    strokeWeight(0);
    rect(0, 175, 800, 625);

    //tree
    fill(110, 82, 81);
    rect(565, 0, 165, 300);
    fill(74, 57, 56);
    rect(560, 0, 45, 300);
    rect(660, 0, 70, 300);
    triangle(600, 150, 500, 200, 580, 90);

    //house2
    fill(73, 107, 81);
    ellipse(600, 550, 1000, 800);
    fill(191, 157, 157);
    ellipse(555, 475, 425, 475);
    ellipse(380, 465, 325, 425);
    ellipse(760, 505, 350, 450);
    fill(64, 61, 61);
    ellipse(547, 485, 350, 430);

    //door2
    fill(62, 112, 138);
    stroke(69, 77, 94);
    strokeWeight(1);
    ellipse(560, 475, 325, 400);
    fill(64, 61, 61);
    strokeWeight(0);
    rect(425, 330, 5, 290);
    rect(460, 310, 5, 330);
    rect(500, 280, 5, 400);
    rect(545, 275, 5, 400);
    rect(595, 280, 5, 400);
    rect(650, 311, 5, 329);
    rect(707, 401, 5, 158);

    //doorknob2
    fill(64, 61, 61);
    ellipse(557, 480, 40, 40);
    fill(115, 104, 100);
    strokeWeight(1);
    ellipse(545, 480, 40, 40);

    //window1
    fill(64, 61, 61);
    strokeWeight(0);
    ellipse(305, 405, 105, 120);
    fill(83, 92, 112);
    ellipse(310, 400, 95, 110);
    fill(64, 61, 51);
    rect(303, 345, 4, 110);
    rect(262, 400, 95, 4);

    //window2
    fill(64, 61, 61);
    strokeWeight(0);
    ellipse(800, 460, 110, 125);
    fill(83, 92, 112);
    ellipse(805, 455, 100, 115);
    fill(64, 61, 61);
    rect(792, 400, 4, 115);
    rect(750, 455, 100, 4);

    //stairs
    fill(135, 119, 120);
    quad(410, 755, 590, 753, 650, 780, 450, 780);
    fill(64, 61, 61);
    rect(450, 780, 200, 30);

    //flowers1
    fill(75, 94, 75);
    ellipse(280, 645, 110, 80);
    fill(147, 123, 150);
    ellipse(260, 630, 20, 20);
    ellipse(250, 660, 15, 15);
    fill(93, 115, 93);
    ellipse(320, 660, 120, 80);
    fill(222, 217, 149);
    ellipse(280, 660, 15, 15);
    ellipse(290, 670, 20, 20);
    ellipse(337, 650, 15, 15);

    //flowers2
    fill(60, 77, 60);
    ellipse(740, 690, 145, 115);
    fill(197, 230, 230);
    ellipse(730, 670, 25, 25);
    ellipse(750, 690, 15, 15);
    ellipse(785, 710, 20, 20);
    fill(75, 94, 75);
    ellipse(680, 700, 130, 100);
    fill(115, 60, 91);
    ellipse(650, 680, 25, 25);
    ellipse(690, 710, 20, 20);
    ellipse(710, 690, 15, 15);
    ellipse(720, 720, 15, 15);
    
    //plant1
    fill(107, 135, 110);
    ellipse(375, 730, 80, 300);
    fill(93, 117, 95);
    ellipse(435, 760, 80, 300);
    fill(121, 153, 125);
    ellipse(400, 705, 80, 290);
    fill(228, 235, 228);
    ellipse(425, 660, 20, 20);
    ellipse(370, 770, 25, 25);
    ellipse(350, 700, 16, 16);
    ellipse(450, 680, 20, 20);

    //tree roots
    fill(74, 57, 56);
    triangle(600, 150, 500, 200, 560, 150);
    triangle(730, 150, 770, 220, 700, 150);

    //signature
    fill(64, 61, 61);
    textSize(18);
    text('R. C. J. Maas', 15, 785);
}